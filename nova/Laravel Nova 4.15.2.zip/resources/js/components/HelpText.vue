<template>
  <p class="help-text">
    <slot />
  </p>
</template>

<script>
export default {}
</script>
